# File: Example_3Mix.R
# Author: Kyle Carter
# Contact: kcarter@math.arizona.edu

# This file contains an example of RAD use for a sink generated
# by a mixture of three source samples.

#Get required functions
library("robCompositions")
source("RAD.R")

#Load Data
Testset <- read.table("3Mix.txt",header=T,comment='',check=F,sep='\t')

#Perform RAD
Testres=RAD(Testset[,11],Testset[,1:10],10)

#Plot example Results
library(ggplot2)

TrueProp=c(0,0.6,0,0.3,0,0,0.1,0,0,0)
AllDat=data.frame("Method"=factor(c(rep("True",10),rep("RAD",10)),levels=c("True","RAD")),
                  "Sample"=rep(colnames(Testres[[2]]),2),
                  "Proportion"=c(TrueProp,Testres[[2]][3,]))

ggplot(AllDat,aes(x=Sample,y=Proportion,fill=Method)) +
  geom_bar(position=position_dodge(),stat="identity") +
  ggtitle("Example Estimated Proportions") +
  xlab("Sample") +
  theme(plot.title = element_text(hjust = 0.5,size=8), 
        strip.text=element_text(size=8),
        axis.text=element_text(size=8),
        axis.title=element_text(size=8,face="bold"),
        title=element_text(size=8,face="bold"),
        legend.text=element_text(size=8),
        axis.text.x = element_text(angle = 90, hjust = 1))

